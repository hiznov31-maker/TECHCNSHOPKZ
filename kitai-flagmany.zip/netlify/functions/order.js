// Принимает заявку с сайта и отправляет её в Telegram-бот.
// Нужны переменные окружения Netlify: TG_BOT_TOKEN (токен от @BotFather) и TG_CHAT_ID (ваш chat id).
const clip = (v, n) => String(v == null ? "" : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").slice(0, n);
const json = (status, body) => ({ statusCode: status, headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body) });

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { ok: false, error: "method" });
  const token = process.env.TG_BOT_TOKEN, chat = process.env.TG_CHAT_ID;
  if (!token || !chat) return json(500, { ok: false, error: "not_configured" });
  let d;
  try { d = JSON.parse(event.body || "{}"); } catch (e) { return json(400, { ok: false, error: "json" }); }
  if (d.hp) return json(200, { ok: true }); // ловушка для ботов
  const contact = clip(d.contact, 80).trim();
  if (contact.length < 5) return json(400, { ok: false, error: "contact" });
  const text = [
    "Новая заявка " + clip(d.orderNo, 30),
    "",
    clip(d.item, 300),
    "Сумма: " + clip(d.total, 40),
    "",
    "Имя: " + (clip(d.name, 60).trim() || "не указано"),
    "Контакт: " + contact,
    "",
    "Текст заказа:",
    clip(d.text, 900),
  ].join("\n");
  try {
    const r = await fetch("https://api.telegram.org/bot" + token + "/sendMessage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chat, text, disable_web_page_preview: true }),
    });
    if (!r.ok) return json(502, { ok: false, error: "telegram" });
    return json(200, { ok: true });
  } catch (e) {
    return json(502, { ok: false, error: "network" });
  }
};
